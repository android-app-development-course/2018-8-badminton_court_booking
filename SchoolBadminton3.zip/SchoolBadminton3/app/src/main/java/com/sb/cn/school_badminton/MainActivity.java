package com.sb.cn.school_badminton;

import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.view.GravityCompat;
import android.support.v4.view.ViewPager;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import com.sb.cn.school_badminton.InfoField.InfoFragment;
import com.sb.cn.school_badminton.OrderField.OrderFragment;
import com.sb.cn.school_badminton.GameField.GameFragment;
import com.sb.cn.school_badminton.PersonField.PersonFragment;
import com.sb.cn.school_badminton.OrderField.SBDatabase;
import com.sb.cn.school_badminton.OrderField.SetStatusBar;
import com.sb.cn.school_badminton.OrderField.ViewPagerAdapter;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private NavigationView navigationView;
    private DrawerLayout drawerLayout;


    private ViewPager viewPager;
    private List<Fragment> fragmentsList=new ArrayList<>();
    private ViewPagerAdapter adapter;

    private Toolbar toolbar;
    private ActionBar actionBar;

    private TextView learn_normal, learn_choose, learn_text_normal, learn_text_choose;
    private TextView communication_normal, communication_choose, communication_text_normal, communication_text_choose;
    private TextView achievement_normal, achievement_choose, achievement_text_normal, achievement_text_choose;
    private TextView shop_normal, shop_choose, shop_text_normal, shop_text_choose;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        SetStatusBar.setTranslucentWindows(this);   //设置透明状态栏





        toolbar = (Toolbar) findViewById(R.id.toolbar_layout);
        setSupportActionBar(toolbar);//这里有问题
        toolbar.setTitleTextColor(Color.rgb(255,255,255));
        actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
            actionBar.setHomeAsUpIndicator(R.drawable.ic_leftout_menu);
        }


        drawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);//左滑出菜单栏

        initButton();
        initFragment();
        initButtonbg();

        learn_choose.getBackground().setAlpha(255);
        learn_text_choose.setTextColor(Color.argb(255, 236, 21, 21));
        //初始化，默认选中第一个


        //NavigationView 设置点击事件
        navigationView=(NavigationView)findViewById(R.id.navigation_view);
        navigationView.setNavigationItemSelectedListener(
                new NavigationView.OnNavigationItemSelectedListener() {
                    @Override
                    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                        return false;
                    }
                });

        View navHeaderView=navigationView.getHeaderView(0);
        TextView loginText=(TextView)navHeaderView.findViewById(R.id.nav_header_login);
        loginText.setOnClickListener(this);
        TextView futureCEO=(TextView)navHeaderView.findViewById(R.id.nav_header_name);
        futureCEO.setOnClickListener(this);


        //设置Fragment

        //创建数据库
        SBDatabase dbHelper=new SBDatabase(this,"SBData.db",null,1);
        dbHelper.getWritableDatabase();

    }

    private void initButton() {
        learn_normal = (TextView) findViewById(R.id.learn_normal);
        learn_choose = (TextView) findViewById(R.id.learn_choose);
        learn_text_normal = (TextView) findViewById(R.id.learn_text_normal);
        learn_text_choose = (TextView) findViewById(R.id.learn_text_choose);
        communication_normal = (TextView) findViewById(R.id.communication_normal);
        communication_choose = (TextView) findViewById(R.id.communication_choose);
        communication_text_normal = (TextView) findViewById(R.id.communication_text_normal);
        communication_text_choose = (TextView) findViewById(R.id.communication_text_choose);
        achievement_normal = (TextView) findViewById(R.id.achievement_normal);
        achievement_choose = (TextView) findViewById(R.id.achievement_choose);
        achievement_text_normal = (TextView) findViewById(R.id.achievement_text_normal);
        achievement_text_choose = (TextView) findViewById(R.id.achievement_text_choose);
        shop_normal = (TextView) findViewById(R.id.shop_normal);
        shop_choose = (TextView) findViewById(R.id.shop_choose);
        shop_text_normal = (TextView) findViewById(R.id.shop_text_normal);
        shop_text_choose = (TextView) findViewById(R.id.shop_text_choose);
        findViewById(R.id.learn).setOnClickListener(this);
        findViewById(R.id.communication).setOnClickListener(this);
        findViewById(R.id.achievement).setOnClickListener(this);
        findViewById(R.id.shop).setOnClickListener(this);
    }

    private void initButtonbg() {
        learn_normal.getBackground().setAlpha(255);
        learn_choose.getBackground().setAlpha(1);
        learn_text_normal.setTextColor(Color.argb(255, 169, 169, 169));
        learn_text_choose.setTextColor(Color.argb(1, 126, 110, 250));
        communication_normal.getBackground().setAlpha(255);
        communication_choose.getBackground().setAlpha(1);
        communication_text_normal.setTextColor(Color.argb(255, 169, 169, 169));
        communication_text_choose.setTextColor(Color.argb(1, 126, 110, 250));
        achievement_normal.getBackground().setAlpha(255);
        achievement_choose.getBackground().setAlpha(1);
        achievement_text_normal.setTextColor(Color.argb(255, 169, 169, 169));
        achievement_text_choose.setTextColor(Color.argb(1, 126, 110, 250));
        shop_normal.getBackground().setAlpha(255);
        shop_choose.getBackground().setAlpha(1);
        shop_text_normal.setTextColor(Color.argb(255, 169, 169, 169));
        shop_text_choose.setTextColor(Color.argb(1, 126, 110, 250));
    }

    @Override
    public void onClick(View view) {
        initButtonbg();
        switch (view.getId()) {
            case R.id.learn:
                viewPager.setCurrentItem(0, false);
                learn_choose.getBackground().setAlpha(255);
                learn_normal.getBackground().setAlpha(1);
                learn_text_choose.setTextColor(Color.argb(255, 126, 110, 250));
                learn_text_normal.setTextColor(Color.argb(1, 169, 169, 169));
                break;
            case R.id.communication:
                viewPager.setCurrentItem(1, false);
                communication_choose.getBackground().setAlpha(255);
                communication_normal.getBackground().setAlpha(1);
                communication_text_choose.setTextColor(Color.argb(255, 126, 110, 250));
                communication_text_normal.setTextColor(Color.argb(1, 169, 169, 169));
                break;
            case R.id.achievement:
                viewPager.setCurrentItem(2, false);
                achievement_choose.getBackground().setAlpha(255);
                achievement_normal.getBackground().setAlpha(1);
                achievement_text_choose.setTextColor(Color.argb(255, 126, 110, 250));
                achievement_text_normal.setTextColor(Color.argb(1, 169, 169, 169));
                break;
            case R.id.shop:
                viewPager.setCurrentItem(3, false);
                shop_choose.getBackground().setAlpha(255);
                shop_normal.getBackground().setAlpha(1);
                shop_text_choose.setTextColor(Color.argb(255, 126, 110, 250));
                shop_text_normal.setTextColor(Color.argb(1, 169, 169, 169));
                break;
            case R.id.nav_header_login:
                //Intent intent=new Intent(MainActivity.this,SearchActivity.class);
                //startActivity(intent);
                break;
            case R.id.nav_header_name:
                //Intent CEOintent=new Intent(MainActivity.this, HomepagerActivity.class);
                //startActivity(CEOintent);
            default:
                break;
        }
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                drawerLayout.openDrawer((GravityCompat.START));
                break;
            default:
                break;
        }
        return true;
    }

    private void initFragment(){

        viewPager = (ViewPager) findViewById(R.id.view_pager);

        OrderFragment orderFragment=new OrderFragment();
        InfoFragment infoFragment=new InfoFragment();
        GameFragment gameFragment=new GameFragment();
        PersonFragment personFragment=new PersonFragment();


        fragmentsList.add(orderFragment);
        fragmentsList.add(infoFragment);
        fragmentsList.add(gameFragment);
        fragmentsList.add(personFragment);

        adapter = new ViewPagerAdapter(getSupportFragmentManager(), fragmentsList, null);
        viewPager.setOffscreenPageLimit(4);
        viewPager.setAdapter(adapter);
        viewPager.setCurrentItem(0);
        int id = getIntent().getIntExtra("id", 0);
        if (id == 1) {
            viewPager.setCurrentItem(2);
        }
        viewPager.setOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
                int alpha_one = (int) (255 * positionOffset);
                int alpha_two = (int) (255 * (1 - positionOffset));

                switch (position) {
                    case 0:
                        learn_normal.getBackground().setAlpha(alpha_one);
                        learn_choose.getBackground().setAlpha(alpha_two);
                        learn_text_normal.setTextColor(Color.argb(alpha_one, 169, 169, 169));
                        learn_text_choose.setTextColor(Color.argb(alpha_two, 126, 110, 250));
                        communication_normal.getBackground().setAlpha(alpha_two);
                        communication_choose.getBackground().setAlpha(alpha_one);
                        communication_text_normal.setTextColor(Color.argb(alpha_two, 169, 169, 169));
                        communication_text_choose.setTextColor(Color.argb(alpha_one, 126, 110, 250));
                        break;
                    case 1:
                        communication_normal.getBackground().setAlpha(alpha_one);
                        communication_choose.getBackground().setAlpha(alpha_two);
                        communication_text_normal.setTextColor(Color.argb(alpha_one, 169, 169, 169));
                        communication_text_choose.setTextColor(Color.argb(alpha_two, 126, 110, 250));
                        achievement_normal.getBackground().setAlpha(alpha_two);
                        achievement_choose.getBackground().setAlpha(alpha_one);
                        achievement_text_normal.setTextColor(Color.argb(alpha_two, 169, 169, 169));
                        achievement_text_choose.setTextColor(Color.argb(alpha_one, 126, 110, 250));
                        break;
                    case 2:
                        achievement_normal.getBackground().setAlpha(alpha_one);
                        achievement_choose.getBackground().setAlpha(alpha_two);
                        achievement_text_normal.setTextColor(Color.argb(alpha_one, 169, 169, 169));
                        achievement_text_choose.setTextColor(Color.argb(alpha_two, 126, 110, 250));
                        shop_normal.getBackground().setAlpha(alpha_two);
                        shop_choose.getBackground().setAlpha(alpha_one);
                        shop_text_normal.setTextColor(Color.argb(alpha_two, 169, 169, 169));
                        shop_text_choose.setTextColor(Color.argb(alpha_one, 126, 110, 250));
                        break;

                }
            }

            @Override
            public void onPageSelected(int position) {

            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });
    }
}
