package com.sb.cn.school_badminton.InfoField;

import android.content.Context;
import java.util.ArrayList;
import com.sb.cn.school_badminton.R;

public class NewsUtils {
    public static ArrayList<NewsBean> getAllNews(Context context) {
        ArrayList<NewsBean> arrayList = new ArrayList<>();
        for (int i = 0; i < 5; i++) {
            NewsBean newsBean1 = new NewsBean();
            newsBean1.title = "小黄人两连败于韩呈恺/周昊东";
            newsBean1.des = "印尼男双组合苏卡穆约/费尔纳迪无疑是2018赛季羽毛球男双领域的绝对霸主，但是两人曾在中国公开赛、法国公开赛两连败于中国小将组合韩呈恺/周昊东。";
            newsBean1.icon = context.getResources().getDrawable(R.drawable.xiaohuangren);
            newsBean1.news_url = "https://www.aiyuke.com/news/2018/12/na91412f142f.html";
            arrayList.add(newsBean1);

            NewsBean newsBean2 = new NewsBean();
            newsBean2.title = "戴资颖教练成中国台北主教练";
            newsBean2.des = "018年12月，中国台北羽协6日上午召开会议，针对2020东京奥运国家队总教练一职进行审议，5位评委一致通过赖建诚担任中国台北羽球队总教练，任期将从2019年2月1日起，至2020东京奥运会结束为止。";
            newsBean2.icon = context.getResources().getDrawable(R.drawable.daiziying);
            newsBean2.news_url = "https://www.aiyuke.com/news/2018/12/n68cba6d9522.html";
            arrayList.add(newsBean2);

            NewsBean newsBean3 = new NewsBean();
            newsBean3.title = "羽联公布2018年度最佳提名”";
            newsBean3.des = "今日，世界羽联公布了2018年年度最佳运动员提名名单，包括年度最佳男、女运动员，最有潜力运动员，最佳进步运动员，最佳残疾男、女运动员等合计六个奖项。";
            newsBean3.icon = context.getResources().getDrawable(R.drawable.yulian);
            newsBean3.news_url = "http://3g.163.com/dy/article/E2EFNCP30529D75J.html";
            arrayList.add(newsBean3);
        }
        return arrayList;
    }

}