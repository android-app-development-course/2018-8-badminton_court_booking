package com.sb.cn.school_badminton.GameField;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.sb.cn.school_badminton.R;

import java.util.ArrayList;
import java.util.List;

public class GameActivity extends AppCompatActivity {
    List<Game> gameList;
    MyOpenHelper myOpenHelper;
    SQLiteDatabase db;
    MyAdapter myAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ListView lv = (ListView) findViewById(R.id.lv);
        gameList= new ArrayList<Game>();
        myOpenHelper = new MyOpenHelper(this);
        db = myOpenHelper.getWritableDatabase();
        myAdapter = new MyAdapter(this);
//        myAdapter.clear();
//        myAdapter.Insert();
        myAdapter.Query();
        lv.setAdapter(myAdapter);
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            @Override
            public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3)
            {
                Bundle bundle = new Bundle();
                System.out.println("看看这是啥"+arg2);
                bundle.putString("name",gameList.get(arg2).getGameName());
                bundle.putString("date",gameList.get(arg2).getGameDate());
                bundle.putString("info",gameList.get(arg2).getGameInfo());
                bundle.putString("location",gameList.get(arg2).getGameLocation());
                bundle.putString("sponsor",gameList.get(arg2).getSponsor());
//                System.out.println(gameList.get(arg2).getTitle()+"  在MAIN "+gameList.get(arg2).getTime());
                Intent intenta = new Intent();
                intenta.putExtras(bundle);
                intenta.setClass(GameActivity.this,ContentActivity.class);
                startActivity(intenta);
            }


        });



    }



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();


        return super.onOptionsItemSelected(item);
    }

    class MyAdapter extends BaseAdapter{
        private Context context;
        private LayoutInflater inflater;

        @Override
        public int getCount()
        {
            return gameList.size();
        }

        @Override
        public long getItemId(int position)
        {
            return 0;
        }

        @Override
        public Object getItem(int position) {
            return null;
        }

        public MyAdapter(Context context)
        {
            this.context = context;
            inflater = LayoutInflater.from(context);
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent){
            Game n = gameList.get(position);
            ViewHolder viewHolder = null;
            if(convertView ==null)
            {
                viewHolder = new ViewHolder();
                convertView = inflater.inflate(R.layout.game_list_item,null);
                viewHolder.text_Name = (TextView) convertView.findViewById(R.id.item_tv);
                convertView.setTag(viewHolder);
            }
            else {
                viewHolder = (ViewHolder) convertView.getTag();
            }
            viewHolder.text_Name.setText(n.getGameName());
            return convertView;
        }


        class ViewHolder{
            private TextView text_Name;
        }

        public void clear()
        {
            db.execSQL("DELETE FROM  Game");
//            db.execSQL("drop table Note");
        }



        public void Insert()
        {
            ContentValues values = new ContentValues();
            values.put("info","今天不是舔狗");
            values.put("location","不知道明天是不是舔狗");
            values.put("date","2016nian 11 16");
            values.put("sponsor","我啊");
            values.put("name","新生杯吧");
            db.insert("Game",null,values);
        }



        public void Query(){
            Cursor cursor = db.query("Game",null,null,null,null,null,null);
            while (cursor.moveToNext()){
                int _id = cursor.getInt(0);
                String info = cursor.getString(1);
                String date = cursor.getString(2);
                String location = cursor.getString(3);
                String sponsor = cursor.getString(4);
                String name = cursor.getString(5);
                int sign = cursor.getInt(6);
//                String time = cursor.getTime()
//                System.out.println(title+"????"+content);
                Game note = new Game(info,date,location,sponsor,name,sign);
                gameList.add(note);
            }
        }
    }
}