package com.sb.cn.school_badminton.OrderField;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Administrator on 2018/1/28/028.
 */

public class ViewPagerAdapter extends FragmentPagerAdapter {
    List<Fragment> mFragment=new ArrayList<>();
    List<String> titles;

    public ViewPagerAdapter(FragmentManager fm, List<Fragment> mFragment, List<String> titles){
        super(fm);
        this.mFragment=mFragment;
        this.titles=titles;
    }

    @Override
    public Fragment getItem(int position){
        return mFragment.get(position);
    }

    @Override
    public int getCount(){
        return mFragment.size();
    }

    @Override
    public CharSequence getPageTitle(int position){
        return titles.get(position);
    }
}
