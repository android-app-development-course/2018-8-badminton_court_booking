package com.sb.cn.school_badminton.PersonField;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ListView;

import com.sb.cn.school_badminton.R;

import java.util.ArrayList;
import java.util.List;

public class PersonBookActivity extends AppCompatActivity{

    private List<BookInfo> bookInfoList;
    private PersonBookDatabase personBookDatabase;
    private SQLiteDatabase db;
    private PersonBookAdapter personBookAdapter;
    private ListView book_lv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_person_book);
        init();
        Cursor cursor = db.query("data2person_book", null, null, null, null, null, null);
        while (cursor.moveToNext()) {
            String date = cursor.getString(cursor.getColumnIndex("date"));
            String time = cursor.getString(cursor.getColumnIndex("time"));
            BookInfo bookInfo = new BookInfo(date, time);
            bookInfoList.add(bookInfo);
        }
        cursor.close();

        personBookAdapter = new PersonBookAdapter(this, bookInfoList);
        book_lv.setAdapter(personBookAdapter);

        db.close();
    }

    public void init() {
        bookInfoList = new ArrayList<BookInfo>();
        personBookDatabase = new PersonBookDatabase(this);
        book_lv = (ListView) findViewById(R.id.book_lv);
        db = personBookDatabase.getReadableDatabase();
    }
}