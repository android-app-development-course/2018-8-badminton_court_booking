package com.sb.cn.school_badminton.PersonField;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.sb.cn.school_badminton.R;

public class PersonFragment extends Fragment implements View.OnClickListener {

    private Button btu_info;
    private Button btu_book;
    private Button btu_game;
    private Button btu_set;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle saveInstanceState){
        View view=inflater.inflate(R.layout.fragment_person,container,false);
        init(view);
        return view;
    }
    @Override
    public void onActivityCreated(Bundle saveInstanceState){
        super.onActivityCreated(saveInstanceState);
    }

    private void init(View view) {
        btu_info = (Button)view.findViewById(R.id.btu_info); btu_info.setOnClickListener(this);
        btu_book = (Button)view.findViewById(R.id.btu_book); btu_book.setOnClickListener(this);
        btu_game = (Button)view.findViewById(R.id.btu_game); btu_game.setOnClickListener(this);
        btu_set = (Button)view.findViewById(R.id.btu_set); btu_set.setOnClickListener(this);
    }

    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btu_info:
                Intent intent1 = new Intent(getContext(), PersonInfoActivity.class);
                startActivity(intent1);
                break;
            case R.id.btu_book:
                Intent intent2 = new Intent(getContext(), PersonBookActivity.class);
                startActivity(intent2);
                break;
            case R.id.btu_game:
                Intent intent3 = new Intent(getContext(), PersonGameActivity.class);
                startActivity(intent3);
                break;
            case R.id.btu_set:
                Intent intent4 = new Intent(getContext(), PersonSettingActivity.class);
                startActivity(intent4);
                break;
        }
    }

}
