package com.sb.cn.school_badminton.PersonField;

public class BookInfo {
    private String date;
    private String time;

    public BookInfo(String date, String time) {
        super();
        this.date = date;
        this.time = time;
    }

    public String getDate() {
        return date;
    }

    public String getTime() {
        return time;
    }
}
