package com.sb.cn.school_badminton.PersonField;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class PersonGameDatabase extends SQLiteOpenHelper {

    public static final String CREATE_PERSON_GAME="create table data2person_game("
            +"name text primary key, "
            +"time text, "
            +"addr text, "
            +"initiator text)";

    private Context context;

    public PersonGameDatabase(Context context) {
        super(context, "PersonGameData.db", null, 1);
        this.context = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_PERSON_GAME);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db,int oldVersion,int newVersion){

    }
}
