package com.sb.cn.school_badminton.PersonField;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ListView;

import com.sb.cn.school_badminton.R;

import java.util.ArrayList;
import java.util.List;

public class PersonGameActivity extends AppCompatActivity{

    private List<GameInfo> gameInfoList;
    private PersonGameDatabase personGameDatabase;
    private SQLiteDatabase db;
    private PersonGameAdapter personGameAdapter;
    private ListView game_lv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_person_game);
        init();
        Cursor cursor = db.query("data2person_game", null, null, null, null, null, null);
        while (cursor.moveToNext()) {
            String name = cursor.getString(cursor.getColumnIndex("name"));
            String time = cursor.getString(cursor.getColumnIndex("time"));
            String addr = cursor.getString(cursor.getColumnIndex("addr"));
            String initiator = cursor.getString(cursor.getColumnIndex("initiator"));
            GameInfo gameInfo = new GameInfo(name, time, addr, initiator);
            gameInfoList.add(gameInfo);
        }
        cursor.close();

        personGameAdapter = new PersonGameAdapter(this, gameInfoList);
        game_lv.setAdapter(personGameAdapter);

        db.close();
    }

    public void init() {
        gameInfoList = new ArrayList<GameInfo>();
        personGameDatabase = new PersonGameDatabase(this);
        game_lv = (ListView) findViewById(R.id.game_lv);
        db = personGameDatabase.getReadableDatabase();
    }
}