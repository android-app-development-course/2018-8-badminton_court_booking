package com.sb.cn.school_badminton.OrderField;

public class DayOrderRecord {
    private YearMonthDay curDay;
    private String stituation;

    public DayOrderRecord(YearMonthDay curDay,String stituation){
        this.curDay=curDay;
        this.stituation=stituation;
    }

    private YearMonthDay getCurDay(){
        return curDay;
    }

    private String getStituation(){
        return stituation;
    }
}
