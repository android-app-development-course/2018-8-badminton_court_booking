package com.sb.cn.school_badminton.OrderField;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.sb.cn.school_badminton.R;

import java.util.List;

//暂时没用

public class OrderDataAdapter extends RecyclerView.Adapter
        <OrderDataAdapter.ViewHolder> {

    private List<Order> orderLists;

    class ViewHolder extends RecyclerView.ViewHolder{
        private TextView period;
        private TextView canOrder;


        public ViewHolder(View view){
            super(view);

        }
    }

    public OrderDataAdapter(List<Order> orderLists){
        this.orderLists=orderLists;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int ViewType){
        View view= LayoutInflater.from(parent.getContext())
                .inflate(R.layout.view_data_item,parent,false);
        ViewHolder holder=new ViewHolder(view);

        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });

        return holder;
    }
    @Override
    public void onBindViewHolder(ViewHolder holder,int position){
        Order o=orderLists.get(position);
        holder.period.setText(""+o.getPeriod()+":00-"+(o.getPeriod()+1)+":00");
        if(o.isCanOrder()){
            holder.canOrder.setText("点击预约");
        }else{
            holder.canOrder.setText("已被预约");
        }
    }
    @Override
    public int getItemCount(){
        return orderLists.size();
    }
}
