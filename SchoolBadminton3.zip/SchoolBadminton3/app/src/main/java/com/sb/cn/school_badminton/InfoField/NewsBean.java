package com.sb.cn.school_badminton.InfoField;

import android.graphics.drawable.Drawable;
public class NewsBean {
    public String title;
    public String des;
    public Drawable icon;
    public String news_url;

}