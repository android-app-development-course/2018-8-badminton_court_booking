package com.sb.cn.school_badminton.OrderField;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.sb.cn.school_badminton.R;

public class OrderActivity extends AppCompatActivity {

    public static final String ORDER_DATA_CHOOSED="order_data_choosed";
    public static final String ORDER_PERIOD_CHOOSED="order_period_choosed";
    public static final String BACK_PERIOD="back_period";
    public static final String AMOUNT_PAID="amount_paid";
    public static final int PAY_REQUEST_CODE=8;

    private int period;

    private static final int NO_CHOOSE=0;
    private static final int ALIBABA_PAY=1;
    private static final int WEIXIN_PAY=2;

    private ImageView alibaba;
    private ImageView weixin;


    private int payChoose=NO_CHOOSE;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order);

        ActionBar actionBar =getSupportActionBar();
        if(actionBar!=null){
            actionBar.setDisplayHomeAsUpEnabled(true);
        }

        initBind();
        initIntent();

    }

    private void initIntent(){
        YearMonthDay d=(YearMonthDay) getIntent().getSerializableExtra(ORDER_DATA_CHOOSED);
        period=getIntent().getIntExtra(ORDER_PERIOD_CHOOSED,8);
        int paid=getIntent().getIntExtra(AMOUNT_PAID,30);
        ((TextView)findViewById(R.id.choose_data)).setText("预约日期: "+d.getYear()+" 年 "+d.getMonth()+" 月 "+d.getDay()+" 日");
        ((TextView)findViewById(R.id.choose_period)).setText("预约时段: "+period+":00-"+(period+1)+":00");
        ((TextView)findViewById(R.id.paid)).setText("预约金额: "+paid+"元");
    }

    private void initBind(){
        alibaba=(ImageView) findViewById(R.id.alibaba_choose);
        weixin=(ImageView) findViewById(R.id.weixin_choose);

        alibaba.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(payChoose!=ALIBABA_PAY){
                    alibaba.setImageResource(R.mipmap.choose);
                    weixin.setImageResource(R.mipmap.wait_choose);
                    payChoose=ALIBABA_PAY;
                }else{
                    alibaba.setImageResource(R.mipmap.wait_choose);
                    payChoose=NO_CHOOSE;
                }
            }
        });

        weixin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(payChoose!=WEIXIN_PAY){
                    weixin.setImageResource(R.mipmap.choose);
                    alibaba.setImageResource(R.mipmap.wait_choose);
                    payChoose=WEIXIN_PAY;
                }else{
                    weixin.setImageResource(R.mipmap.wait_choose);
                    payChoose=NO_CHOOSE;
                }
            }
        });

        TextView payment=(TextView) findViewById(R.id.payment);
        payment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(payChoose==ALIBABA_PAY){
                    alibabaPaid();
                }else if(payChoose==WEIXIN_PAY){
                    weixinPaid();
                }else{
                    Toast.makeText(OrderActivity.this,"请选择支付方式",Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    private boolean alibabaPaid(){
        Toast.makeText(OrderActivity.this,"通过支付宝支付成功！",Toast.LENGTH_SHORT).show();
        backIntent(RESULT_OK);
        return true;
    }

    private boolean weixinPaid(){
        Toast.makeText(OrderActivity.this,"通过微信支付成功！",Toast.LENGTH_SHORT).show();
        backIntent(RESULT_OK);
        return true;
    }

    private void backIntent(final int flag){
        Intent intent =new Intent();
        intent.putExtra(BACK_PERIOD,period);
        setResult(flag,intent);
        finish();
    }



    private boolean goToPay(int choose){
        return false;
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        switch (item.getItemId()){
            case android.R.id.home:
                backIntent(RESULT_CANCELED);
                finish();
                break;
            default:
                break;
        }
        return true;
    }


    @Override
    public void onBackPressed(){
        backIntent(RESULT_CANCELED);
        finish();
    }

}
