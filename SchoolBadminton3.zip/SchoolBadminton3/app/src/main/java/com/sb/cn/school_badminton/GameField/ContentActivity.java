package com.sb.cn.school_badminton.GameField;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.sb.cn.school_badminton.MainActivity;
import com.sb.cn.school_badminton.R;

import com.sb.cn.school_badminton.PersonField.PersonGameDatabase;

public class ContentActivity extends AppCompatActivity {
    TextView text_name;
    TextView text_date;
    TextView text_info;
    TextView text_sponsor;
    TextView text_location;
    Button btn_join;
    Button btn_lala;
    MyOpenHelper myOpenHelper;
    SQLiteDatabase db;
    PersonGameDatabase personGameDatabase;
    SQLiteDatabase db2;
    int sign;
    String str_name;
    String str_date;
    String str_info;
    String str_location;
    String str_sponsor;
    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.game_content);
        Bundle bundle = getIntent().getExtras();
        text_name = (TextView) findViewById(R.id.content_name);
        text_date = (TextView) findViewById(R.id.content_date);
        text_info = (TextView) findViewById(R.id.content_info);
        text_sponsor = (TextView) findViewById(R.id.content_sponsor);
        text_location = (TextView) findViewById(R.id.content_location);
        btn_join = (Button) findViewById(R.id.content_btn);
        str_name = bundle.getString("name");
        str_date = bundle.getString("date");
        str_info = bundle.getString("info");
        str_location = bundle.getString("location");
        str_sponsor = bundle.getString("sponsor");
        myOpenHelper = new MyOpenHelper(this);
        db = myOpenHelper.getWritableDatabase();
        personGameDatabase = new PersonGameDatabase(this);
        db2 = personGameDatabase.getWritableDatabase();
        sign = bundle.getInt("sign");
        text_name.setText(str_name);
        text_date.setText(str_date);
        text_info.setText(str_info);
        text_sponsor.setText(str_sponsor);
        text_location.setText(str_location);
        if(sign==1)
            btn_join.setText("取消报名");
        btn_join.setOnClickListener(listener);
        btn_join.setOnClickListener(listener);
    }
    private View.OnClickListener listener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if(sign == 0){
                System.out.println("有没有signa"+"   "+sign);
                Toast.makeText(getApplicationContext(),"报名成功！",Toast.LENGTH_SHORT).show();
                ContentValues values = new ContentValues();
                ContentValues values2 = new ContentValues();
                values.put("sign",1);
                values2.put("name", str_name);
                values2.put("time", str_date);
                values2.put("addr", str_location);
                values2.put("initiator", str_sponsor);
                db.update("Game",values,"name=?",new String[]{str_name});
                db2.insert("data2person_game", null, values2);
                Intent intent = new Intent(ContentActivity.this, MainActivity.class);
                intent.putExtra("id",1);
                startActivity(intent);
            }
            else {
                Toast.makeText(getApplicationContext(),"报名取消",Toast.LENGTH_SHORT).show();
                ContentValues values1 = new ContentValues();
                values1.put("sign",0);
                db.update("Game",values1,"name=?",new String[]{str_name});
                db2.delete("data2person_game", "name=?", new String[]{str_name});
                Intent intenta = new Intent(ContentActivity.this, MainActivity.class);
                intenta.putExtra("id",1);
                startActivity(intenta);
            }
        }
    };

}
