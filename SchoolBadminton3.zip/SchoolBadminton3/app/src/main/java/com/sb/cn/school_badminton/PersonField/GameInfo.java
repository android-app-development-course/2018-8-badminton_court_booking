package com.sb.cn.school_badminton.PersonField;

public class GameInfo {
    private String name;
    private String time;
    private String addr;
    private String initiator;

    public GameInfo(String name, String time, String addr, String initiator) {
        super();
        this.name = name;
        this.time = time;
        this.addr = addr;
        this.initiator = initiator;
    }

    public String getName() {
        return name;
    }

    public String getTime() {
        return time;
    }

    public String getAddr() {
        return addr;
    }

    public String getInitiator() {
        return initiator;
    }
}
