package com.sb.cn.school_badminton.OrderField;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.sb.cn.school_badminton.R;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by zhuguohui on 2016/11/8.
 */

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.MyViewHolder> {
    private Context mContext;
    private OnChoosedListener listener;
    private int choosedNumber;
    private int preNumber;

    private static List<YearMonthDay> dataList = new ArrayList<>();
    private static int data_name = 0;
    public MyAdapter(Context mContext,YearMonthDay systemData){
        this.mContext=mContext;
        setData(systemData);
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View view = inflater.inflate(R.layout.view_data_item, parent, false);
        return new MyViewHolder(view);
    }


    private void setData(YearMonthDay systemData){
        dataList.clear();

        int year=systemData.getYear();
        int month=systemData.getMonth();

        SBDatabase dbHelper=new SBDatabase(mContext,"SBData.db",null,1);
        int n=0;
        for(int i=systemData.getMonth();i<systemData.getMonth()+5;i++){
            if(i>12){
                month=i%12;
            }
            int daySum=createData(year,month);
            for(int j=1;j<=daySum;j++){
                YearMonthDay d=new YearMonthDay(year,month,j);
                //写入数据库
                Date2orderSet.insertToDB(dbHelper,d,"11111111111");
                dataList.add(d);
                if(YearMonthDay.twoEqual(d,systemData)){
                    preNumber=choosedNumber=n;
                }
                n++;
            }
            if(i==12){
                year++;
            }
        }

    }

    @Override
    public void onBindViewHolder(final MyViewHolder holder, final int position){
        final YearMonthDay appointDay = dataList.get(position);
        holder.tv_title.setText(""+appointDay.getDay());
        if(position==preNumber){
            holder.tv_title.setBackgroundResource(R.drawable.circle_blank);
        }
        if(position==choosedNumber){
            holder.tv_title.setBackgroundResource(R.drawable.circle);
            Log.d(">>>>>>>>>>>>>>>>>>>>>>",""+position);
        }

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //预约数据刷新  设置背景
                YearMonthDay choosedData=dataList.get(position);
                listener.chooseWhat(choosedData);
                preNumber=choosedNumber;
                choosedNumber=position;
                //notifyItemChanged(preNumber);
                //notifyItemChanged(choosedNumber);//为什么会闪烁，这个就不会
                notifyDataSetChanged();
            }
        });
    }


    @Override
    public int getItemCount() {
        return dataList.size();
    }


    class MyViewHolder extends RecyclerView.ViewHolder {
        TextView tv_title;

        public MyViewHolder(View itemView) {
            super(itemView);
            tv_title = (TextView) itemView.findViewById(R.id.day);
        }
    }

    public void updateData() {
        data_name++;
        dataList.clear();
        //setData();    ??这个干嘛用的

    }
    private int createData(int year ,int month){
        if(month==1 || month==3 || month==5 || month==7 || month==8 || month==10 || month==12){
            return 31;
        }
        if(month==4 || month==6 || month==11){
            return 30;
        }
        if(month==2){
            if(year%400==0){
                return 29;
            }else if(year%100!=0 || year%4==0){
                return 29;
            }else{
                return 28;
            }
        }
        return 31;
    }

    public interface OnChoosedListener{
        void chooseWhat(YearMonthDay choosed);
    }

    public void setOnChoosedListener(OnChoosedListener listener){
        this.listener=listener;
    }


}
