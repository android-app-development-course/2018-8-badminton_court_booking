package com.sb.cn.school_badminton.GameField;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class MyOpenHelper extends SQLiteOpenHelper {
    public MyOpenHelper(Context context)
    {
        super(context,"Game.db",null,2);
        System.out.println("MyOpenHelper");
    }

    @Override
    public void onCreate(SQLiteDatabase db)
    {
        db.execSQL("create table Game(_id integer primary key autoincrement,info text,date text,location text,sponsor text,name text,sign integer)");
        ContentValues values = new ContentValues();
        values.put("info","男子、女子单打赛，一局21分，两局三胜、直至决出冠军、亚军、季军。");
        values.put("location","南区体育馆三楼C馆3、4号场地");
        values.put("date","2018年12月24日下午14:00 - 2018年12月25日下午18:00");
        values.put("sponsor","华师石牌校区羽毛球协会");
        values.put("name","“新生杯”羽毛球赛");
        values.put("sign",0);
        db.insert("Game",null,values);

        ContentValues values1 = new ContentValues();
        values1.put("info","团体赛制，男子单打、女子单打、男双、女双、混双，一局21分，见三收、打至淘汰赛改为三局15分制度，最后进入决赛。");
        values1.put("location","南区体育馆三楼B馆5、6号场地");
        values1.put("date","2019年1月1日下午14:00 - 2018年1月2日下午18:00");
        values1.put("sponsor","华师计算机学院羽毛球院队");
        values1.put("name","“教职工”羽毛球赛");
        values1.put("sign",0);
        db.insert("Game",null,values1);

        ContentValues values2 = new ContentValues();
        values2.put("info","院际赛，男子单打、女子单打、混双三项，每局21分，赢一局得一分，小组赛前两名出线，" +
                "小组出线第一对抗另一小组第二，比赛后决出四强，再半决赛，决赛，决出前三名");
        values2.put("location","手球馆1、2、3号场地");
        values2.put("date","2019年1月16日下午14:00 - 2018年1月17日下午18:00");
        values2.put("sponsor","华师羽毛球协会");
        values2.put("name","“院际赛”羽毛球赛");
        values2.put("sign",0);
        db.insert("Game",null,values2);







    }

    @Override
    public void onUpgrade(SQLiteDatabase db,int oldVersion,int newVersion)
    {
        System.out.println("MyOpenHelper.onUpgrade");
    }
}
