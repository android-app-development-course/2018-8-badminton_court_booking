package com.sb.cn.school_badminton.OrderField;

public class Order {
    private int period;
    private boolean canOrder;

    public Order(int period,boolean canOrder){
        this.period=period;
        this.canOrder=canOrder;
    }

    public int getPeriod() {
        return period;
    }

    public boolean isCanOrder() {
        return canOrder;
    }
}
