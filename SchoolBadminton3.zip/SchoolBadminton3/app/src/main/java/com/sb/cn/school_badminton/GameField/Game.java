package com.sb.cn.school_badminton.GameField;

public class Game {
    private String GameInfo;  //比赛信息
    private String GameDate;  //比赛日期
    private String GameLocation; //比赛地点
    private String Sponsor;//比赛发起人
    private String GameName; //比赛名称
    private int sign;

    public Game(String Info,String Date,String Location,String Sponsor,String Name,int sign)
    {
        this.GameInfo = Info;
        this.GameDate = Date;
        this.GameLocation = Location;
        this.Sponsor = Sponsor;
        this.GameName = Name;
        this.sign = sign;
    }
    public int getSign(){return this.sign;}
    public String getGameInfo()
    {
        return this.GameInfo;
    }
    public String getGameDate()
    {
        return this.GameDate;
    }
    public String getGameName()
    {
        return this.GameName;
    }
    public String getSponsor()
    {
        return this.Sponsor;
    }
    public String getGameLocation()
    {
        return this.GameLocation;
    }

    public void setGameInfo(String info)
    {
        this.GameInfo = info;
    }
    public void setGameDate(String date)
    {
        this.GameDate = date;
    }
    public void setGameLocation(String location)
    {
        this.GameLocation = location;
    }
    public void setGameName(String name)
    {
        this.GameName = name;
    }
    public void setSponsor(String sponsor)
    {
        this.Sponsor = sponsor;
    }
    public void setSign(int sign){this.sign=sign;}

}
