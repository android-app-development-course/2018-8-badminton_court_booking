package com.sb.cn.school_badminton.PersonField;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.sb.cn.school_badminton.R;

import java.util.List;

public class PersonBookAdapter extends BaseAdapter {

    private Context context;
    private LayoutInflater inflater;
    private List<BookInfo> bookInfoList;

    public PersonBookAdapter(Context context, List<BookInfo> bookInfoList) {
        super();
        this.context = context;
        this.bookInfoList = bookInfoList;
        inflater = LayoutInflater.from(context);
    }

    public int getCount() {
        return this.bookInfoList.size();
    }

    public long getItemId(int position) {
        return 0;
    }

    public Object getItem(int position) {
        return null;
    }

    public View getView(int position, View convertView, ViewGroup parent) {
        BookInfo bookInfo = this.bookInfoList.get(position);
        View view;
        if (convertView == null) {
            view = inflater.inflate(R.layout.person_book_item, null);
        } else {
            view = convertView;
        }

        TextView pb_item_date = (TextView) view.findViewById(R.id.pb_item_date);
        TextView pb_item_time = (TextView) view.findViewById(R.id.pb_item_time);
        pb_item_date.setText(bookInfo.getDate());
        pb_item_time.setText(bookInfo.getTime());
        return view;
    }
}
