package com.sb.cn.school_badminton.OrderField;

import android.app.Activity;
import android.graphics.Color;
import android.os.Build;
import android.view.View;

/**
 * 创建日期 2018/3/16/016.
 * 设置状态栏 状态
 * 实现状态栏透明或者自定义颜色
 * 去掉标题栏
 */

public class SetStatusBar {
    public static void setTranslucentWindows(Activity activity){
        if(Build.VERSION.SDK_INT>=21){
            View decorView =activity.getWindow().getDecorView();
            decorView.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
            activity.getWindow().setStatusBarColor(Color.TRANSPARENT);
        }
    }
    public static void setClearWindows(Activity activity){
        if(Build.VERSION.SDK_INT>=21){
            View decorView =activity.getWindow().getDecorView();
            decorView.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    |View.SYSTEM_UI_FLAG_FULLSCREEN
                    |View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    |View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
            activity.getWindow().setStatusBarColor(Color.TRANSPARENT);
        }
    }

}
