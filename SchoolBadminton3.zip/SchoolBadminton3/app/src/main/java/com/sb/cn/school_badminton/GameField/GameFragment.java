package com.sb.cn.school_badminton.GameField;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.sb.cn.school_badminton.GameField.ContentActivity;
import com.sb.cn.school_badminton.GameField.Game;
import com.sb.cn.school_badminton.GameField.GameActivity;
import com.sb.cn.school_badminton.GameField.MyOpenHelper;
import com.sb.cn.school_badminton.R;

import java.util.ArrayList;
import java.util.List;

public class GameFragment extends Fragment {
    List<Game> gameList;
    MyOpenHelper myOpenHelper;
    SQLiteDatabase db;
    MyAdapter myAdapter;
     Button btn_join;
    public ListView lv;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle saveInstanceState){
        View view=inflater.inflate(R.layout.fragment_game,container,false);

        String trystr="1101";
        char c1=trystr.charAt(2);
        StringBuilder cur=new StringBuilder(trystr);
        cur.setCharAt(2,'1');
        trystr=cur.toString();

//        ((TextView)view.findViewById(R.id.lv)).setText(""+c1+"----"+trystr);

        btn_join = (Button) view.findViewById(R.id.item_btn);
//        btn_join.setOnClickListener(listener);
          lv = (ListView) view.findViewById(R.id.lv);
        gameList= new ArrayList<Game>();
        myOpenHelper = new MyOpenHelper(getContext());
        db = myOpenHelper.getWritableDatabase();
        myAdapter = new MyAdapter(getContext());
//        myAdapter.clear();
//        myAdapter.Insert();
        myAdapter.Query();
        lv.setAdapter(myAdapter);
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            @Override
            public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3)
            {
                Bundle bundle = new Bundle();
                System.out.println("看看这是啥"+arg2);
                bundle.putString("name",gameList.get(arg2).getGameName());
                bundle.putString("date",gameList.get(arg2).getGameDate());
                bundle.putString("info",gameList.get(arg2).getGameInfo());
                bundle.putString("location",gameList.get(arg2).getGameLocation());
                bundle.putString("sponsor",gameList.get(arg2).getSponsor());
//                System.out.println(gameList.get(arg2).getTitle()+"  在MAIN "+gameList.get(arg2).getTime());
                Intent intenta = new Intent();
                intenta.putExtras(bundle);
                intenta.setClass(getContext(),ContentActivity.class);
                startActivity(intenta);
            }


        });
        return view;
    }
    @Override
    public void onActivityCreated(Bundle saveInstanceState){
        super.onActivityCreated(saveInstanceState);
    }





    class MyAdapter extends BaseAdapter {
        private Context context;
        private LayoutInflater inflater;

        @Override
        public int getCount()
        {
            return gameList.size();
        }

        @Override
        public long getItemId(int position)
        {
            return 0;
        }

        @Override
        public Object getItem(int position) {
            return null;
        }

        public MyAdapter(Context context)
        {
            this.context = context;
            inflater = LayoutInflater.from(context);
        }

        @Override
        public View getView(final int position, View convertView, ViewGroup parent){
            final Game n = gameList.get(position);
            MyAdapter.ViewHolder viewHolder = null;
            if(convertView ==null)
            {
                viewHolder = new MyAdapter.ViewHolder();
                convertView = inflater.inflate(R.layout.game_list_item,null);
                viewHolder.text_Name = (TextView) convertView.findViewById(R.id.item_tv);
                viewHolder.btn = (Button)convertView.findViewById(R.id.item_btn);
                convertView.setTag(viewHolder);
            }
            else {
                viewHolder = (MyAdapter.ViewHolder) convertView.getTag();
            }
            viewHolder.text_Name.setText(n.getGameName());
            if(n.getSign() == 1)
            {
                viewHolder.btn.setText("已报名");
            }
            else viewHolder.btn.setText("点击报名→");
            viewHolder.btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Bundle bundle = new Bundle();
                    System.out.println("看看这是啥");
                    bundle.putString("name",n.getGameName());
                    bundle.putString("date",n.getGameDate());
                    bundle.putString("info",n.getGameInfo());
                    bundle.putString("location",n.getGameLocation());
                    bundle.putString("sponsor",n.getSponsor());
                    bundle.putInt("sign",n.getSign());
//                System.out.println(gameList.get(arg2).getTitle()+"  在MAIN "+gameList.get(arg2).getTime());
                    Intent intenta = new Intent();
                    intenta.putExtras(bundle);

                    intenta.setClass(getContext(),ContentActivity.class);
                    startActivity(intenta);
                }
            });
            return convertView;
        }


        class ViewHolder{
            private TextView text_Name;
            private Button btn;
        }

        public void clear()
        {
//            db.execSQL("DELETE FROM  Game");
            db.execSQL("drop table Game");
        }



        public void Insert()
        {
            ContentValues values = new ContentValues();
            values.put("info","男子、女子单打赛，一局21分，两局三胜、直至决出冠军、亚军、季军。");
            values.put("location","南区体育馆三楼C馆3、4号场地");
            values.put("date","2018年12月24日下午14:00 - 2018年12月25日下午18:00");
            values.put("sponsor","华师石牌校区羽毛球协会");
            values.put("name","“新生杯”羽毛球赛");
            db.insert("Game",null,values);
        }



        public void Query(){
            Cursor cursor = db.query("Game",null,null,null,null,null,null);
            while (cursor.moveToNext()){
                int _id = cursor.getInt(0);
                String info = cursor.getString(1);
                String date = cursor.getString(2);
                String location = cursor.getString(3);
                String sponsor = cursor.getString(4);
                String name = cursor.getString(5);
                int sign  =cursor.getInt(6);
//                String time = cursor.getTime()
//                System.out.println(title+"????"+content);
                Game note = new Game(info,date,location,sponsor,name,sign);
                gameList.add(note);
            }
        }
    }
}
