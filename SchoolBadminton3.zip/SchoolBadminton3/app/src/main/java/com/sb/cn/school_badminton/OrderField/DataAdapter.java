package com.sb.cn.school_badminton.OrderField;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;


import com.sb.cn.school_badminton.R;

import java.util.List;

public class DataAdapter extends RecyclerView.Adapter<DataAdapter.ViewHolder> {

    private List<YearMonthDay> dataLists;

    class ViewHolder extends RecyclerView.ViewHolder{
        private TextView day;
        private TextView lunarDay;

        public ViewHolder(View view){
            super(view);
            day=(TextView)view.findViewById(R.id.day);

        }

    }

    public DataAdapter(List<YearMonthDay> dataLists){
        this.dataLists=dataLists;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int ViewType){
        View view= LayoutInflater.from(parent.getContext())
                .inflate(R.layout.view_data_item,parent,false);

        ViewHolder holder=new ViewHolder(view);

        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });

        return holder;
    }
    @Override
    public void onBindViewHolder(ViewHolder holder,int position){
        YearMonthDay d=dataLists.get(position);
        holder.day.setText(""+d.getDay());
        holder.lunarDay.setText(d.getLunarDay());
    }
    @Override
    public int getItemCount(){
        return dataLists.size();
    }

}
