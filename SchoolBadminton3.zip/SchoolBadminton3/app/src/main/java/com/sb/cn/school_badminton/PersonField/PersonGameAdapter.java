package com.sb.cn.school_badminton.PersonField;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.sb.cn.school_badminton.R;

import java.util.List;

public class PersonGameAdapter extends BaseAdapter {

    private Context context;
    private LayoutInflater inflater;
    private List<GameInfo> gameInfoList;

    public PersonGameAdapter(Context context, List<GameInfo> gameInfoList) {
        super();
        this.context = context;
        this.gameInfoList = gameInfoList;
        inflater = LayoutInflater.from(context);
    }

    public int getCount() {
        return this.gameInfoList.size();
    }

    public long getItemId(int position) {
        return 0;
    }

    public Object getItem(int position) {
        return null;
    }

    public View getView(int position, View convertView, ViewGroup parent) {
        GameInfo gameInfo = this.gameInfoList.get(position);
        View view;
        if (convertView == null) {
            view = inflater.inflate(R.layout.person_game_item, null);
        } else {
            view = convertView;
        }

        TextView pg_item_name = (TextView) view.findViewById(R.id.pg_item_name);
        TextView pg_item_time = (TextView) view.findViewById(R.id.pg_item_time);
        TextView pg_item_addr = (TextView) view.findViewById(R.id.pg_item_addr);
        TextView pg_item_initiator = (TextView) view.findViewById(R.id.pg_item_initiator);
        pg_item_name.setText(gameInfo.getName());
        pg_item_time.setText(gameInfo.getTime());
        pg_item_addr.setText(gameInfo.getAddr());
        pg_item_initiator.setText(gameInfo.getInitiator());
        return view;
    }
}
