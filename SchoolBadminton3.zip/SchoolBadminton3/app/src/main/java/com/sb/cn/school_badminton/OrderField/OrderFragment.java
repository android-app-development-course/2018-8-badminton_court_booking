package com.sb.cn.school_badminton.OrderField;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.RecyclerView;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.sb.cn.school_badminton.R;
import com.sb.cn.school_badminton.PersonField.PersonBookDatabase;

import java.util.Calendar;

import static android.app.Activity.RESULT_CANCELED;
import static android.app.Activity.RESULT_OK;

public class OrderFragment extends Fragment implements PagingScrollHelper.onPageChangeListener,View.OnClickListener {
    private static final int PERIOD_COUNT=11;
    private SBDatabase dbHelper;   //初始化
    //时段
    private TextView canOrder_8;
    private TextView canOrder_9;
    private TextView canOrder_10;
    private TextView canOrder_11;
    private TextView canOrder_14;
    private TextView canOrder_15;
    private TextView canOrder_16;
    private TextView canOrder_17;
    private TextView canOrder_19;
    private TextView canOrder_20;
    private TextView canOrder_21;

    private static final int PRICE_ONE_HOUR=30;

    private ObserveScrollView scrv;
    private YearMonthDay systemData;
    private YearMonthDay choosedData;
    private String choosedStituation="00000000000";
    private TextView detailOrder;
    private TextView detailOrderBlue;
    private TextView yearMonth;


    private int height=2000;

    MyAdapter dataAdapter;
    PagingScrollHelper scrollHelper=new PagingScrollHelper();


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle saveInstanceState){
        View view=inflater.inflate(R.layout.fragment_order,container,false);
        //获取系统时间
        Calendar calendar=Calendar.getInstance();
        systemData=new YearMonthDay(calendar.get(Calendar.YEAR),calendar.get(Calendar.MONTH)+1,calendar.get(Calendar.DAY_OF_MONTH));
        choosedData=systemData;
        initBind(view);
        //
        initDataRcv(view);
        dbHelper=new SBDatabase(getContext(),"SBData.db",null,1);
        //展示当天信息
        updateOrder(systemData);

        LinearLayout scrollHeight=(LinearLayout)view.findViewById(R.id.scroll_height);
        height=getViewHeight(scrollHeight,true);


        scrv.setScrollListener(new ObserveScrollView.ScrollListener() {
            @Override
            public void scrollOritention(int l, int t, int oldl, int oldt) {
                if(t>height){
                    detailOrderBlue.setVisibility(View.VISIBLE);
                }else{
                    detailOrderBlue.setVisibility(View.GONE);
                }
            }
        });

        return view;
    }

    private void initBind(View view){
        yearMonth=(TextView) view.findViewById(R.id.year_month);
        yearMonth.setText(""+systemData.getYear()+" 年 "+systemData.getMonth()+" 月");

        detailOrder=(TextView)view.findViewById(R.id.detail_order);
        detailOrderBlue=(TextView)view.findViewById(R.id.detail_order_blue);

        scrv=(ObserveScrollView)view.findViewById(R.id.scrv);

        canOrder_8=(TextView)view.findViewById(R.id.can_order_8); canOrder_8.setOnClickListener(this);
        canOrder_9=(TextView)view.findViewById(R.id.can_order_9); canOrder_9.setOnClickListener(this);
        canOrder_10=(TextView)view.findViewById(R.id.can_order_10); canOrder_10.setOnClickListener(this);
        canOrder_11=(TextView)view.findViewById(R.id.can_order_11); canOrder_11.setOnClickListener(this);
        canOrder_14=(TextView)view.findViewById(R.id.can_order_14); canOrder_14.setOnClickListener(this);
        canOrder_15=(TextView)view.findViewById(R.id.can_order_15); canOrder_15.setOnClickListener(this);
        canOrder_16=(TextView)view.findViewById(R.id.can_order_16); canOrder_16.setOnClickListener(this);
        canOrder_17=(TextView)view.findViewById(R.id.can_order_17); canOrder_17.setOnClickListener(this);
        canOrder_19=(TextView)view.findViewById(R.id.can_order_19); canOrder_19.setOnClickListener(this);
        canOrder_20=(TextView)view.findViewById(R.id.can_order_20); canOrder_20.setOnClickListener(this);
        canOrder_21=(TextView)view.findViewById(R.id.can_order_21); canOrder_21.setOnClickListener(this);
    }

    //判断时段预约情况
    private boolean isPeriodCanOrder(int i){
        char c=choosedStituation.charAt(i);
        if(c=='1') return true;
        else return false;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.can_order_8:
                if(isPeriodCanOrder(0)) initIntent(8);
                else  Toast.makeText(getContext(),"该时段不可预约",Toast.LENGTH_SHORT).show();
                break;
            case R.id.can_order_9:
                if(isPeriodCanOrder(1)) initIntent(9);
                else  Toast.makeText(getContext(),"该时段不可预约",Toast.LENGTH_SHORT).show();
                break;
            case R.id.can_order_10:
                if(isPeriodCanOrder(2)) initIntent(10);
                else  Toast.makeText(getContext(),"该时段不可预约",Toast.LENGTH_SHORT).show();
                break;
            case R.id.can_order_11:
                if(isPeriodCanOrder(3)) initIntent(11);
                else  Toast.makeText(getContext(),"该时段不可预约",Toast.LENGTH_SHORT).show();
                break;
            case R.id.can_order_14:
                if(isPeriodCanOrder(4)) initIntent(14);
                else  Toast.makeText(getContext(),"该时段不可预约",Toast.LENGTH_SHORT).show();
                break;
            case R.id.can_order_15:
                if(isPeriodCanOrder(5)) initIntent(15);
                else  Toast.makeText(getContext(),"该时段不可预约",Toast.LENGTH_SHORT).show();
                break;
            case R.id.can_order_16:
                if(isPeriodCanOrder(6)) initIntent(16);
                else  Toast.makeText(getContext(),"该时段不可预约",Toast.LENGTH_SHORT).show();
                break;
            case R.id.can_order_17:
                if(isPeriodCanOrder(7)) initIntent(17);
                else  Toast.makeText(getContext(),"该时段不可预约",Toast.LENGTH_SHORT).show();
                break;
            case R.id.can_order_19:
                if(isPeriodCanOrder(8)) initIntent(19);
                else  Toast.makeText(getContext(),"该时段不可预约",Toast.LENGTH_SHORT).show();
                break;
            case R.id.can_order_20:
                if(isPeriodCanOrder(9)) initIntent(20);
                else  Toast.makeText(getContext(),"该时段不可预约",Toast.LENGTH_SHORT).show();
                break;
            case R.id.can_order_21:
                if(isPeriodCanOrder(10)) initIntent(21);
                else  Toast.makeText(getContext(),"该时段不可预约",Toast.LENGTH_SHORT).show();
                break;
        }
    }



    private void initIntent(int period){
        Intent intent =new Intent(getContext(),OrderActivity.class);
        intent.putExtra(OrderActivity.ORDER_DATA_CHOOSED,choosedData);
        intent.putExtra(OrderActivity.ORDER_PERIOD_CHOOSED,period);
        intent.putExtra(OrderActivity.AMOUNT_PAID,PRICE_ONE_HOUR);
        startActivityForResult(intent,OrderActivity.PAY_REQUEST_CODE);
    }

    @Override
    public void onActivityCreated(Bundle saveInstanceState){
        super.onActivityCreated(saveInstanceState);
    }


    private RecyclerView.ItemDecoration lastItemDecoration = null;
    private HorizontalPageLayoutManager horizontalPageLayoutManager = null;
    //private PagingItemDecoration pagingItemDecoration = null;

    private void initDataRcv(View view){
        horizontalPageLayoutManager = new HorizontalPageLayoutManager(5, 7);
        //pagingItemDecoration = new PagingItemDecoration(getContext(), horizontalPageLayoutManager);

        RecyclerView dataRcy=(RecyclerView) view.findViewById(R.id.rcv_data);

        DisplayMetrics dm = getResources().getDisplayMetrics();
        int width = dm.widthPixels;

        LinearLayout.LayoutParams params=(LinearLayout.LayoutParams)dataRcy.getLayoutParams();
        params.height=(int) (width/7.0*5);
        dataRcy.setLayoutParams(params);


        dataAdapter = new MyAdapter(getContext(),systemData);
        dataAdapter.setOnChoosedListener(new MyAdapter.OnChoosedListener() {
            @Override
            public void chooseWhat(YearMonthDay choosed) {
                updateOrder(choosed);
            }
        });

        dataRcy.setAdapter(dataAdapter);

        dataRcy.setHorizontalScrollBarEnabled(true);

        scrollHelper.setUpRecycleView(dataRcy);

        //设置监听页面变化事件
        scrollHelper.setOnPageChangeListener(this);




        RecyclerView.LayoutManager layoutManager = null;
        //RecyclerView.ItemDecoration itemDecoration = null;
        layoutManager = horizontalPageLayoutManager;
        //itemDecoration = pagingItemDecoration;
        if (layoutManager != null) {
            dataRcy.setLayoutManager(layoutManager);
            //dataRcy.removeItemDecoration(lastItemDecoration);
            //dataRcy.addItemDecoration(itemDecoration);
            scrollHelper.updateLayoutManger();
            scrollHelper.scrollToPosition(0);
            //lastItemDecoration = itemDecoration;
        }


        //((DefaultItemAnimator)dataRcy.getItemAnimator()).setSupportsChangeAnimations(false);
        //((SimpleItemAnimator)dataRcy.getItemAnimator()).setSupportsChangeAnimations(false);
        //dataRcy.getItemAnimator().setChangeDuration(0);
        /*
        RecyclerView.ItemAnimator animator = dataRcy.getItemAnimator();
        if (animator instanceof SimpleItemAnimator) {
            ((SimpleItemAnimator) animator).setSupportsChangeAnimations(false);
        }
         */

    }


    @Override
    public void onPageChange(int index) {
        int y=systemData.getYear();
        int m=systemData.getMonth()+index;
        if(m>12){
            y++;
            m=m%12;
        }
        yearMonth.setText(""+y+" 年 "+m+" 月");
    }

    private void updateData() {

    }


    /*
     * 主要用来在用户选择日期日期后
     * 从数据库库查询该日期的各个时段预约情况
     * 展示到预约展示模块界面
     * 涉及数据库的查询、数据返回、界面更新
     */
    private void updateOrder(YearMonthDay c){
        choosedData=c;   //用户选择的日期
        detailOrder.setText("正在查询中...");  //
        detailOrderBlue.setText("正在查询中...");  //设置textview的展示
        //进行数据库查询
        if(!YearMonthDay.minCmp(choosedData,systemData)){
            //对比选择的日期，只有在系统前面的日期才需要查询
            //历史数据统一显示已被预约
            String s=Date2orderSet.checkFromDB(dbHelper,c);   //
            Log.d("------------>",s);   //测试日期是否正确
            if(!s.equals("查询无果") && choosedStituation.length()>=PERIOD_COUNT){
                choosedStituation=s;
                //得到当天的信息并展示       展示格式 “2018年12月20日”
                detailOrder.setText(""+c.getYear()+"年"+c.getMonth()+"月"+c.getDay()+"日 场地预约情况");
                detailOrderBlue.setText(""+c.getYear()+"年"+c.getMonth()+"月"+c.getDay()+"日 场地预约情况");
            }else{
                choosedStituation="00000000000";
                detailOrder.setText("查询无果");
                detailOrderBlue.setText("查询无果");
            }
        }else{
            detailOrder.setText(""+c.getYear()+"年"+c.getMonth()+"月"+c.getDay()+"日 场地预约情况");
            detailOrderBlue.setText(""+c.getYear()+"年"+c.getMonth()+"月"+c.getDay()+"日 场地预约情况");
            choosedStituation="00000000000";
        }



        //延时 操作

        if(isPeriodCanOrder(0)){
            canOrder_8.setText("点击预约"); canOrder_8.getBackground().setAlpha(255);
        }else{
            canOrder_8.setText("已被预约"); canOrder_8.getBackground().setAlpha(150);
        }
        if(isPeriodCanOrder(1)){
            canOrder_9.setText("点击预约"); canOrder_9.getBackground().setAlpha(255);
        }else{
            canOrder_9.setText("已被预约"); canOrder_9.getBackground().setAlpha(150);
        }
        if(isPeriodCanOrder(2)){
            canOrder_10.setText("点击预约"); canOrder_10.getBackground().setAlpha(255);
        }else{
            canOrder_10.setText("已被预约"); canOrder_10.getBackground().setAlpha(150);
        }
        if(isPeriodCanOrder(3)){
            canOrder_11.setText("点击预约"); canOrder_11.getBackground().setAlpha(255);
        }else{
            canOrder_11.setText("已被预约"); canOrder_11.getBackground().setAlpha(150);
        }
        if(isPeriodCanOrder(4)){
            canOrder_14.setText("点击预约"); canOrder_14.getBackground().setAlpha(255);
        }else{
            canOrder_14.setText("已被预约"); canOrder_14.getBackground().setAlpha(150);
        }
        if(isPeriodCanOrder(5)){
            canOrder_15.setText("点击预约"); canOrder_15.getBackground().setAlpha(255);
        }else{
            canOrder_15.setText("已被预约"); canOrder_15.getBackground().setAlpha(150);
        }
        if(isPeriodCanOrder(6)){
            canOrder_16.setText("点击预约"); canOrder_16.getBackground().setAlpha(255);
        }else{
            canOrder_16.setText("已被预约"); canOrder_16.getBackground().setAlpha(150);
        }
        if(isPeriodCanOrder(7)){
            canOrder_17.setText("点击预约"); canOrder_17.getBackground().setAlpha(255);
        }else{
            canOrder_17.setText("已被预约"); canOrder_17.getBackground().setAlpha(150);
        }
        if(isPeriodCanOrder(8)){
            canOrder_19.setText("点击预约"); canOrder_19.getBackground().setAlpha(255);
        }else{
            canOrder_19.setText("已被预约"); canOrder_19.getBackground().setAlpha(150);
        }
        if(isPeriodCanOrder(9)){
            canOrder_20.setText("点击预约"); canOrder_20.getBackground().setAlpha(255);
        }else{
            canOrder_20.setText("已被预约"); canOrder_20.getBackground().setAlpha(150);
        }
        if(isPeriodCanOrder(10)){
            canOrder_21.setText("点击预约"); canOrder_21.getBackground().setAlpha(255);
        }else{
            canOrder_21.setText("已被预约"); canOrder_21.getBackground().setAlpha(150);
        }
    }


    public static int getViewHeight(View view, boolean isHeight) {
        int result;
        if (view == null) return 0;
        if (isHeight) {
            int h = View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED);
            view.measure(h, 0);
            result = view.getMeasuredHeight();
        } else {
            int w = View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED);
            view.measure(0, w);
            result = view.getMeasuredWidth();
        }
        return result;
    }

    /*
    //更新数据库
    private void updateToDB(YearMonthDay d,String news){
        SQLiteDatabase  db=dbHelper.getWritableDatabase();
        ContentValues  values=new ContentValues();
        values.put("orderInfo",news);
        db.update("date2order",values,"date=?",new String[]{d.toText()});
    }

    private void insertToDB(YearMonthDay d,String s){
        SQLiteDatabase db=dbHelper.getWritableDatabase();
        ContentValues values =new ContentValues();

        values.put("date",d.toText());
        values.put("orderInfo",s);
        db.insert("date2order",null,values);
    }

    private String checkFromDB(YearMonthDay d){
        String stituaiton;
        SQLiteDatabase db=dbHelper.getWritableDatabase();
        //这里对不对
        Cursor cursor=db.query("date2order",null,"date=?",new String[]{d.toText()},null,null,null);
        if(cursor.moveToFirst()){
            stituaiton=cursor.getString(cursor.getColumnIndex("orderInfo"));
            return  stituaiton;
        }else{
            Toast.makeText(getContext(), "查询无果", Toast.LENGTH_SHORT).show();
            return "查询无果";
        }
    }
     */

    @Override
    public void onActivityResult(int requestCode,int resultCode,Intent data){
        switch (requestCode){
            case OrderActivity.PAY_REQUEST_CODE:
                if(resultCode==RESULT_OK){
                    int peroid=data.getIntExtra(OrderActivity.BACK_PERIOD,0);
                    //时间段
                    String time=""+peroid+":00-"+(peroid+1)+":00";
                    peroid=period2index(peroid);
                    StringBuilder s=new StringBuilder(choosedStituation);
                    s.setCharAt(peroid,'0');
                    choosedStituation=s.toString();
                    Date2orderSet.updateToDB(dbHelper,choosedData,choosedStituation);
                    updateOrder(choosedData);
                    //日期
                    String date=choosedData.toText();

                    PersonBookDatabase personBookDatabase = new PersonBookDatabase(getContext());
                    SQLiteDatabase db = personBookDatabase.getWritableDatabase();
                    ContentValues values = new ContentValues();
                    values.put("date",date);
                    values.put("time",time);
                    db.insert("data2person_book", null, values);
                }else if(resultCode==RESULT_CANCELED){
                    Toast.makeText(getContext(), "订单终止", Toast.LENGTH_SHORT).show();
                }else{

                }
                break;
            default:
        }
    }

    private int period2index(int period){
        if(period==8) return 0;
        else if(period==9) return 1;
        else if(period==10) return 2;
        else if(period==11) return 3;
        else if(period==14) return 4;
        else if(period==15) return 5;
        else if(period==16) return 6;
        else if(period==17) return 7;
        else if(period==19) return 8;
        else if(period==20) return 9;
        else return 10;
    }
}
