package com.sb.cn.school_badminton.OrderField;

import java.io.Serializable;

public class YearMonthDay implements Serializable {
    private int year;
    private int month;
    private int day;
    private String lunarDay=null;

    public YearMonthDay(int year,int month,int day){
        this.year=year;
        this.month=month;
        this.day=day;
    }

    public YearMonthDay(int year,int month,int day,String lunarDay){
        this.year=year;
        this.month=month;
        this.day=day;
        this.lunarDay=lunarDay;
    }

    public String toText(){
        String dText=""+year;
        if(month<10){
            dText+=("-0"+month);
        }else{
            dText+=("-"+month);
        }
        if(day<10){
            dText+=("-0"+day);
        }else{
            dText+=("-"+day);
        }
        return dText;
    }
    public int getYear(){
        return year;
    }

    public int getMonth(){
        return month;
    }

    public int getDay(){
        return day;
    }

    public String getLunarDay(){
        return lunarDay;
    }

    public static boolean twoEqual(YearMonthDay d1,YearMonthDay d2){
        if(d1.getYear()==d2.getYear() && d1.getMonth()==d2.getMonth() && d1.getDay()==d2.getDay()){
            return true;
        }else{
            return false;
        }
    }

    public static boolean minCmp(YearMonthDay d1,YearMonthDay d2){
        if(d1.getYear()<d2.getYear()){
            return true;
        }else if(d1.getYear()==d2.getYear()){
            if(d1.getMonth()<d2.getMonth()){
                return true;
            }else if(d1.getMonth()==d2.getMonth()){
                if(d1.getDay()<d2.getDay()){
                    return true;
                }else{
                    return false;
                }
            }else{
                return false;
            }
        }else{
            return false;
        }
    }

}
