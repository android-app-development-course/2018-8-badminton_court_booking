package com.sb.cn.school_badminton.OrderField;


import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

// extends SQLiteOpenHelper
public class SBDatabase extends SQLiteOpenHelper{

    public static final String CREATE_ORDER="create table date2order("
            +"date text primary key ,"
            +"orderInfo text)";

    private Context mContext;


    public SBDatabase(Context mContext, String name , SQLiteDatabase.CursorFactory factory, int version){
        super(mContext,name,factory,version);
        this.mContext=mContext;
    }

    @Override
    public void onCreate(SQLiteDatabase db){
        db.execSQL(CREATE_ORDER);
        Toast.makeText(mContext,"date2order表创建成功", Toast.LENGTH_SHORT).show();
    }
    @Override
    public void onUpgrade(SQLiteDatabase db,int oldVersion,int newVersion){

    }

    public static boolean saveToDB(YearMonthDay day,String newStituation){
        return false;
    }

    public static String readFromDB(YearMonthDay day){
        return "";
    }
}
