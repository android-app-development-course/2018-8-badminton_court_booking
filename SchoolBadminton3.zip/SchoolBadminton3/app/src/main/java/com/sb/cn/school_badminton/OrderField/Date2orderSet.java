package com.sb.cn.school_badminton.OrderField;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

public class Date2orderSet {

    public static void updateToDB(SBDatabase dbHelper,YearMonthDay d,String news){
        SQLiteDatabase db=dbHelper.getWritableDatabase();
        ContentValues values=new ContentValues();
        values.put("orderInfo",news);
        db.update("date2order",values,"date=?",new String[]{d.toText()});
    }

    public static void insertToDB(SBDatabase dbHelper,YearMonthDay d,String s){
        SQLiteDatabase db=dbHelper.getWritableDatabase();
        ContentValues values =new ContentValues();

        values.put("date",d.toText());
        values.put("orderInfo",s);
        db.insert("date2order",null,values);
    }

    public static String checkFromDB(SBDatabase dbHelper,YearMonthDay d){
        String stituaiton;
        SQLiteDatabase db=dbHelper.getWritableDatabase();
        //这里对不对
        Cursor cursor=db.query("date2order",null,"date=?",new String[]{d.toText()},null,null,null);
        if(cursor.moveToFirst()){
            stituaiton=cursor.getString(cursor.getColumnIndex("orderInfo"));
            return  stituaiton;
        }else{
            return "查询无果";
        }
    }
}
